export default class TicketPaymentService {
  /**
   * This class represents a TicketPaymentService responsible for taking payments.
   * It simulates a payment request to an external service (e.g., a payment gateway).
   */

  makePayment(accountId, totalAmountToPay) {
    // Simulate a payment request to an external payment service
    // In a real-world scenario, this is where you would integrate with a payment gateway
    if (!Number.isInteger(accountId) || !Number.isInteger(totalAmountToPay)) {
      throw new TypeError('Invalid input: accountId and totalAmountToPay must be integers.');
    }

    // Simulate successful payment (assume payment always goes through)
    console.log(`Payment of £${totalAmountToPay} made for account ID ${accountId}`);
  }
}
