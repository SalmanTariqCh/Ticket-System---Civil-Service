import TicketTypeRequest from './lib/TicketTypeRequest.js';
import TicketPaymentService from './TicketPaymentService.js';
import SeatReservationService from './SeatReservationService.js';

export default class TicketService {
  constructor(ticketPaymentService, seatReservationService) {
    this.ticketPaymentService = ticketPaymentService;
    this.seatReservationService = seatReservationService;
  }

  purchaseTickets(accountId, ...ticketTypeRequests) {
    // Check if there are any ticket requests
    if (ticketTypeRequests.length === 0) {
      throw new Error('No tickets requested.');
    }

    // Check if the total number of tickets requested exceeds the limit (20)
    const totalTicketsRequested = ticketTypeRequests.reduce(
      (total, request) => total + request.quantity,
      0
    );
    if (totalTicketsRequested > 20) {
      throw new Error('Maximum 20 tickets can be purchased at a time.');
    }

    // Check if an Adult ticket is included when purchasing Child or Infant tickets
    const hasAdultTicket = ticketTypeRequests.some(
      (request) => request.type === 'ADULT'
    );
    const hasChildOrInfantTicket = ticketTypeRequests.some(
      (request) => request.type === 'CHILD' || request.type === 'INFANT'
    );
    if (hasChildOrInfantTicket && !hasAdultTicket) {
      throw new Error('Child or Infant tickets must be purchased with an Adult ticket.');
    }

    // Calculate the total amount to pay
    const totalAmountToPay = this.calculateTotalAmount(ticketTypeRequests);

    // Make a payment request to the TicketPaymentService
    this.ticketPaymentService.makePayment(accountId, totalAmountToPay);

    // Calculate the number of seats to reserve
    const totalSeatsToAllocate = this.calculateTotalSeats(ticketTypeRequests);

    // Make a seat reservation request to the SeatReservationService
    this.seatReservationService.reserveSeat(accountId, totalSeatsToAllocate);
  }

  calculateTotalAmount(ticketTypeRequests) {
    // Define ticket prices
    const ticketPrices = {
      INFANT: 0,
      CHILD: 10,
      ADULT: 20,
    };

    // Calculate the total amount based on ticket type and quantity
    return ticketTypeRequests.reduce((total, request) => {
      return total + ticketPrices[request.type] * request.quantity;
    }, 0);
  }

  calculateTotalSeats(ticketTypeRequests) {
    // Calculate the total number of seats to allocate (excluding infants)
    return ticketTypeRequests
      .filter((request) => request.type !== 'INFANT')
      .reduce((total, request) => total + request.quantity, 0);
  }
}
