import TicketService from './TicketService';

// Mock the external services for payment and seat reservation
const mockPaymentService = {
  makePayment: jest.fn(),
};

const mockReservationService = {
  reserveSeat: jest.fn(),
};

describe('TicketService', () => {
  let ticketService;

  beforeEach(() => {
    ticketService = new TicketService(mockPaymentService, mockReservationService);
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should calculate the total amount correctly for ticket purchase', () => {
    const accountId = 1;
    const ticketTypeRequests = [
      { type: 'ADULT', quantity: 2 },
      { type: 'CHILD', quantity: 3 },
    ];

    const totalAmount = ticketService.calculateTotalAmount(ticketTypeRequests);
    expect(totalAmount).toBe(2 * 20 + 3 * 10); // 2 Adult tickets + 3 Child tickets
  });

  it('should calculate the total seats to allocate correctly', () => {
    const accountId = 1;
    const ticketTypeRequests = [
      { type: 'ADULT', quantity: 2 },
      { type: 'CHILD', quantity: 3 },
      { type: 'INFANT', quantity: 1 },
    ];

    const totalSeats = ticketService.calculateTotalSeats(ticketTypeRequests);
    expect(totalSeats).toBe(2 + 3); // Exclude Infant tickets
  });

  it('should make a payment request to TicketPaymentService', () => {
    const accountId = 1;
    const ticketTypeRequests = [
      { type: 'ADULT', quantity: 2 },
    ];

    ticketService.purchaseTickets(accountId, ...ticketTypeRequests);

    expect(mockPaymentService.makePayment).toHaveBeenCalledWith(accountId, 2 * 20); // Payment for 2 Adult tickets
  });

  it('should make a seat reservation request to SeatReservationService', () => {
    const accountId = 1;
    const ticketTypeRequests = [
      { type: 'ADULT', quantity: 2 },
      { type: 'CHILD', quantity: 3 },
    ];

    ticketService.purchaseTickets(accountId, ...ticketTypeRequests);

    expect(mockReservationService.reserveSeat).toHaveBeenCalledWith(accountId, 2 + 3); // Seats for Adult and Child tickets
  });

  it('should throw an error for invalid purchase with no ticket requests', () => {
    const accountId = 1;

    expect(() => ticketService.purchaseTickets(accountId)).toThrow('No tickets requested.');
  });

  it('should throw an error for exceeding the maximum ticket limit', () => {
    const accountId = 1;
    const ticketTypeRequests = [
      { type: 'ADULT', quantity: 21 }, // Exceeds the limit
    ];

    expect(() => ticketService.purchaseTickets(accountId, ...ticketTypeRequests)).toThrow(
      'Maximum 20 tickets can be purchased at a time.'
    );
  });

  it('should throw an error when purchasing Child/Infant tickets without an Adult ticket', () => {
    const accountId = 1;
    const ticketTypeRequests = [
      { type: 'CHILD', quantity: 2 },
    ];

    expect(() => ticketService.purchaseTickets(accountId, ...ticketTypeRequests)).toThrow(
      'Child or Infant tickets must be purchased with an Adult ticket.'
    );
  });
});
