import TicketPaymentService from './TicketPaymentServiceTest';

describe('TicketPaymentService', () => {
  let paymentService;

  beforeEach(() => {
    paymentService = new TicketPaymentService();
  });

  it('should make a payment successfully', () => {
    const accountId = 1;
    const totalAmountToPay = 100; // Assuming a valid total amount

    // Mock the console.log method to capture the log output
    const consoleLogSpy = jest.spyOn(console, 'log').mockImplementation();

    paymentService.makePayment(accountId, totalAmountToPay);

    // Verify that console.log was called with the expected message
    expect(consoleLogSpy).toHaveBeenCalledWith(`Payment of £${totalAmountToPay} made for account ID ${accountId}`);

    // Restore the original console.log method
    consoleLogSpy.mockRestore();
  });

  it('should throw a TypeError for non-integer accountId', () => {
    const accountId = 'invalidAccountId'; // Invalid account ID
    const totalAmountToPay = 100; // Assuming a valid total amount

    expect(() => paymentService.makePayment(accountId, totalAmountToPay)).toThrow(
      'Invalid input: accountId and totalAmountToPay must be integers.'
    );
  });

  it('should throw a TypeError for non-integer totalAmountToPay', () => {
    const accountId = 1;
    const totalAmountToPay = 'invalidAmount'; // Invalid total amount

    expect(() => paymentService.makePayment(accountId, totalAmountToPay)).toThrow(
      'Invalid input: accountId and totalAmountToPay must be integers.'
    );
  });
});
